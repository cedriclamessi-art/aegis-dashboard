-- ============================================================
-- AEGIS — Migrations additionnelles (002 → 008)
-- Exécuter APRÈS les SQL one-block existants
-- ============================================================

-- ============================================================
-- 002 — CONNECTOR REGISTRY + TOKEN VAULT
-- ============================================================

CREATE TABLE IF NOT EXISTS connector_registry (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    provider          VARCHAR(50) NOT NULL, -- 'meta', 'tiktok', 'google_ads', 'shopify', 'stripe'
    display_name      VARCHAR(100),
    status            VARCHAR(20) DEFAULT 'disconnected', -- connected | disconnected | error | rate_limited
    config            JSONB NOT NULL DEFAULT '{}', -- provider-specific config (non-sensitive)
    last_ping_at      TIMESTAMPTZ,
    last_error        TEXT,
    error_count       INTEGER DEFAULT 0,
    circuit_state     VARCHAR(20) DEFAULT 'closed', -- closed | half_open | open
    circuit_opened_at TIMESTAMPTZ,
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    updated_at        TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, provider)
);

ALTER TABLE connector_registry ENABLE ROW LEVEL SECURITY;
CREATE POLICY connector_registry_tenant ON connector_registry
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);

-- Token Vault — tokens JAMAIS en clair
CREATE TABLE IF NOT EXISTS token_vault (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    provider          VARCHAR(50) NOT NULL,
    token_type        VARCHAR(30) NOT NULL, -- 'access_token' | 'refresh_token' | 'api_key'
    encrypted_value   BYTEA NOT NULL, -- AES-256-GCM encrypted
    iv                BYTEA NOT NULL, -- Initialization vector
    auth_tag          BYTEA NOT NULL, -- GCM auth tag
    expires_at        TIMESTAMPTZ,
    last_rotated_at   TIMESTAMPTZ DEFAULT NOW(),
    is_active         BOOLEAN DEFAULT TRUE,
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, provider, token_type, is_active)
);

ALTER TABLE token_vault ENABLE ROW LEVEL SECURITY;
CREATE POLICY token_vault_tenant ON token_vault
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);

-- OAuth states pour PKCE
CREATE TABLE IF NOT EXISTS oauth_states (
    state             VARCHAR(128) PRIMARY KEY,
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    provider          VARCHAR(50) NOT NULL,
    code_verifier     VARCHAR(256), -- PKCE
    redirect_uri      TEXT,
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    expires_at        TIMESTAMPTZ DEFAULT NOW() + INTERVAL '10 minutes'
);

-- ============================================================
-- 003 — BILLING LEDGER + REVENUE SHARE
-- ============================================================

CREATE TABLE IF NOT EXISTS billing_plans (
    id                VARCHAR(50) PRIMARY KEY, -- 'starter' | 'pro' | 'elite' | 'enterprise'
    display_name      VARCHAR(100) NOT NULL,
    price_monthly     NUMERIC(10,2),
    price_yearly      NUMERIC(10,2),
    stripe_price_id   VARCHAR(100),
    limits            JSONB NOT NULL DEFAULT '{}', -- {products_per_month, agents_enabled, modes_allowed, ...}
    is_active         BOOLEAN DEFAULT TRUE,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO billing_plans (id, display_name, price_monthly, limits) VALUES
('starter',    'Starter',    49.00,   '{"products_per_month": 5,  "modes": ["human"],         "connectors": ["shopify", "stripe"]}'),
('pro',        'Pro',        149.00,  '{"products_per_month": 20, "modes": ["human", "semi"],  "connectors": ["shopify", "stripe", "meta", "tiktok"]}'),
('elite',      'Elite',      399.00,  '{"products_per_month": 100,"modes": ["human","semi","auto"], "connectors": "all", "multi_store": true}'),
('enterprise', 'Enterprise', null,    '{"products_per_month": -1, "modes": "all", "connectors": "all", "sla": true, "multi_region": true}')
ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS billing_subscriptions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    plan_id           VARCHAR(50) REFERENCES billing_plans(id),
    stripe_subscription_id VARCHAR(100),
    stripe_customer_id     VARCHAR(100),
    status            VARCHAR(30) DEFAULT 'trialing', -- trialing | active | past_due | canceled | paused
    trial_ends_at     TIMESTAMPTZ,
    current_period_start TIMESTAMPTZ,
    current_period_end   TIMESTAMPTZ,
    canceled_at       TIMESTAMPTZ,
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    updated_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS billing_ledger (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    type              VARCHAR(50) NOT NULL, -- 'subscription', 'revenue_share', 'refund', 'credit'
    amount            NUMERIC(12,2) NOT NULL,
    currency          VARCHAR(3) DEFAULT 'EUR',
    description       TEXT,
    stripe_payment_id VARCHAR(100),
    metadata          JSONB DEFAULT '{}',
    created_at        TIMESTAMPTZ DEFAULT NOW() -- append-only, NO UPDATE
);

-- Revenue share tracking
CREATE TABLE IF NOT EXISTS revenue_share_events (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    period_start      DATE NOT NULL,
    period_end        DATE NOT NULL,
    total_revenue     NUMERIC(12,2) NOT NULL,
    threshold         NUMERIC(12,2) DEFAULT 200000.00,
    share_rate        NUMERIC(5,4) DEFAULT 0.02,
    share_amount      NUMERIC(12,2),
    status            VARCHAR(20) DEFAULT 'pending', -- pending | invoiced | paid
    stripe_invoice_id VARCHAR(100),
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 004 — AGENT RUNTIME + EVENT BUS
-- ============================================================

CREATE TABLE IF NOT EXISTS agent_runtime_log (
    id                BIGSERIAL,
    tenant_id         UUID REFERENCES tenants(id),
    agent_name        VARCHAR(50) NOT NULL,
    task_id           UUID,
    action            VARCHAR(100) NOT NULL,
    input_hash        VARCHAR(64), -- SHA256 of input (not storing PII)
    output_summary    TEXT,
    status            VARCHAR(20) NOT NULL, -- started | completed | failed | skipped
    duration_ms       INTEGER,
    error_message     TEXT,
    correlation_id    VARCHAR(64),
    created_at        TIMESTAMPTZ DEFAULT NOW()
    -- append-only: NO UPDATE, NO DELETE policy
) PARTITION BY RANGE (created_at);

-- Partitions mensuelles automatiques
CREATE TABLE agent_runtime_log_2025_01 PARTITION OF agent_runtime_log
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
CREATE TABLE agent_runtime_log_2025_02 PARTITION OF agent_runtime_log
    FOR VALUES FROM ('2025-02-01') TO ('2025-03-01');
-- ... ajouter via cron mensuel

CREATE INDEX ON agent_runtime_log (tenant_id, created_at);
CREATE INDEX ON agent_runtime_log (correlation_id);

-- Event Bus inter-agents
CREATE TABLE IF NOT EXISTS event_bus (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID REFERENCES tenants(id),
    event_type        VARCHAR(100) NOT NULL, -- 'pipeline.started', 'roas.below_min', etc.
    source_agent      VARCHAR(50),
    target_agent      VARCHAR(50), -- NULL = broadcast
    payload           JSONB NOT NULL DEFAULT '{}',
    status            VARCHAR(20) DEFAULT 'pending', -- pending | claimed | processed | failed
    claimed_by        VARCHAR(50),
    claimed_at        TIMESTAMPTZ,
    processed_at      TIMESTAMPTZ,
    expires_at        TIMESTAMPTZ DEFAULT NOW() + INTERVAL '24 hours',
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX ON event_bus (status, target_agent, created_at) WHERE status = 'pending';
CREATE INDEX ON event_bus (tenant_id, event_type, created_at);

-- ============================================================
-- 005 — PIPELINE RUNS
-- ============================================================

CREATE TABLE IF NOT EXISTS pipeline_runs (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    product_url       TEXT NOT NULL,
    product_url_hash  VARCHAR(64) NOT NULL, -- SHA256 pour déduplication
    mode              VARCHAR(20) DEFAULT 'human', -- human | semi | auto
    status            VARCHAR(30) DEFAULT 'pending',
    -- pending | mining | copy_generation | asset_creation | store_deploy
    -- | ads_draft | awaiting_approval | ads_live | monitoring | scaling
    -- | paused | completed | failed | cancelled
    current_step      VARCHAR(50),
    steps_completed   JSONB DEFAULT '[]',
    product_data      JSONB DEFAULT '{}', -- données extraites
    assets_ids        JSONB DEFAULT '[]', -- refs vers asset_versions
    campaign_ids      JSONB DEFAULT '[]', -- refs vers campaigns
    error_message     TEXT,
    retry_count       INTEGER DEFAULT 0,
    correlation_id    VARCHAR(64),
    started_at        TIMESTAMPTZ,
    completed_at      TIMESTAMPTZ,
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    updated_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE pipeline_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY pipeline_runs_tenant ON pipeline_runs
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);

-- Approval steps pour Human/Semi control
CREATE TABLE IF NOT EXISTS pipeline_approvals (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pipeline_run_id   UUID NOT NULL REFERENCES pipeline_runs(id),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    step              VARCHAR(50) NOT NULL,
    status            VARCHAR(20) DEFAULT 'pending', -- pending | approved | rejected | timeout
    data_preview      JSONB DEFAULT '{}', -- données à approuver (copy, budget, etc.)
    reviewed_by       UUID, -- user_id
    review_note       TEXT,
    expires_at        TIMESTAMPTZ DEFAULT NOW() + INTERVAL '24 hours',
    created_at        TIMESTAMPTZ DEFAULT NOW(),
    reviewed_at       TIMESTAMPTZ
);

-- ============================================================
-- 006 — ASSET VERSIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS asset_versions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    pipeline_run_id   UUID REFERENCES pipeline_runs(id),
    asset_type        VARCHAR(30) NOT NULL, -- 'copy_fiche', 'copy_hooks', 'image_hero', 'video_ugc', 'landing_page'
    version           INTEGER DEFAULT 1,
    content_hash      VARCHAR(64) NOT NULL, -- SHA256 (idempotence)
    storage_path      TEXT, -- chemin CDN/S3
    content           JSONB, -- pour copy (texte JSON)
    mime_type         VARCHAR(50),
    size_bytes        BIGINT,
    provider          VARCHAR(50), -- 'claude', 'midjourney', 'runwayml', etc.
    metadata          JSONB DEFAULT '{}',
    is_approved       BOOLEAN,
    is_active         BOOLEAN DEFAULT TRUE,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE asset_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY asset_versions_tenant ON asset_versions
    USING (tenant_id = current_setting('app.current_tenant_id')::UUID);

-- ============================================================
-- 007 — RISK EVENTS LOG
-- ============================================================

CREATE TABLE IF NOT EXISTS risk_events (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES tenants(id),
    event_type        VARCHAR(50) NOT NULL,
    -- 'stop_loss_triggered', 'kill_switch_activated', 'budget_cap_hit',
    -- 'roas_below_min', 'pixel_freeze', 'metabolic_throttle', 'attribution_mismatch'
    campaign_id       UUID,
    triggered_by      VARCHAR(50), -- 'risk_engine_agent' | 'manual'
    rule_violated     VARCHAR(100),
    metric_value      NUMERIC,
    threshold_value   NUMERIC,
    action_taken      VARCHAR(100), -- 'campaign_paused', 'tenant_frozen', 'throttle_50pct'
    resolved_at       TIMESTAMPTZ,
    resolved_by       VARCHAR(50),
    metadata          JSONB DEFAULT '{}',
    created_at        TIMESTAMPTZ DEFAULT NOW()
    -- append-only
);

CREATE INDEX ON risk_events (tenant_id, created_at);
CREATE INDEX ON risk_events (event_type, created_at);

-- ============================================================
-- FONCTIONS UTILITAIRES
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER connector_registry_updated_at
    BEFORE UPDATE ON connector_registry
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER pipeline_runs_updated_at
    BEFORE UPDATE ON pipeline_runs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Calculer revenue share automatiquement
CREATE OR REPLACE FUNCTION calculate_revenue_share(p_tenant_id UUID, p_period_start DATE, p_period_end DATE)
RETURNS NUMERIC AS $$
DECLARE
    v_total_revenue NUMERIC;
    v_threshold     NUMERIC := 200000;
    v_share_rate    NUMERIC := 0.02;
BEGIN
    -- Summeriser revenue Shopify sur la période
    SELECT COALESCE(SUM((metadata->>'revenue')::NUMERIC), 0)
    INTO v_total_revenue
    FROM billing_ledger
    WHERE tenant_id = p_tenant_id
      AND type = 'shopify_revenue'
      AND created_at::DATE BETWEEN p_period_start AND p_period_end;

    IF v_total_revenue >= v_threshold THEN
        RETURN ROUND(v_total_revenue * v_share_rate, 2);
    END IF;
    RETURN 0;
END;
$$ LANGUAGE plpgsql;
