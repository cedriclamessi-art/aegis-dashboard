// ============================================================
// AEGIS — Claim Engine
// SELECT FOR UPDATE SKIP LOCKED — idempotent + concurrent-safe
// ============================================================

import { db } from '../utils/db';
import { logger } from '../utils/logger';

export interface Task {
  id: string;
  tenantId: string;
  type: string;
  payload: Record<string, unknown>;
  priority: number;
  retryCount: number;
  maxRetries: number;
  correlationId: string;
  createdAt: Date;
  scheduledAt: Date;
}

export interface TaskResult {
  success: boolean;
  output?: Record<string, unknown>;
  error?: string;
  retryable?: boolean;
}

export class ClaimEngine {
  private readonly workerId: string;
  private readonly workerType: string;
  private isRunning = false;
  private pollIntervalMs: number;

  constructor(workerType: string, pollIntervalMs = 1000) {
    this.workerId = `${workerType}-${process.pid}-${Date.now()}`;
    this.workerType = workerType;
    this.pollIntervalMs = pollIntervalMs;
  }

  // ─── Claim 1 task (atomic) ──────────────────────────────────
  async claimOne(taskTypes: string[]): Promise<Task | null> {
    const result = await db.query<Task & { tenant_id: string; task_type: string }>(
      `UPDATE actions_queue
       SET 
         status = 'claimed',
         claimed_by = $1,
         claimed_at = NOW(),
         updated_at = NOW()
       WHERE id = (
         SELECT id FROM actions_queue
         WHERE status = 'pending'
           AND task_type = ANY($2::text[])
           AND scheduled_at <= NOW()
         ORDER BY priority DESC, scheduled_at ASC
         FOR UPDATE SKIP LOCKED
         LIMIT 1
       )
       RETURNING *`,
      [this.workerId, taskTypes]
    );

    if (result.rows.length === 0) return null;

    const row = result.rows[0];
    return {
      id: row.id,
      tenantId: row.tenant_id,
      type: row.task_type,
      payload: row.payload as Record<string, unknown>,
      priority: row.priority,
      retryCount: row.retry_count,
      maxRetries: row.max_retries,
      correlationId: row.correlation_id,
      createdAt: row.created_at,
      scheduledAt: row.scheduled_at,
    };
  }

  // ─── Complete task ──────────────────────────────────────────
  async complete(taskId: string, output?: Record<string, unknown>): Promise<void> {
    await db.query(
      `UPDATE actions_queue
       SET status = 'completed', completed_at = NOW(), output = $2, updated_at = NOW()
       WHERE id = $1`,
      [taskId, JSON.stringify(output ?? {})]
    );
  }

  // ─── Fail task → retry ou DLQ ───────────────────────────────
  async fail(taskId: string, error: string, retryable = true): Promise<void> {
    await db.query(
      `UPDATE actions_queue
       SET 
         retry_count = retry_count + 1,
         last_error = $2,
         status = CASE
           WHEN $3 = true AND retry_count + 1 < max_retries
             THEN 'pending'
           ELSE 'failed'
         END,
         scheduled_at = CASE
           WHEN $3 = true AND retry_count + 1 < max_retries
             THEN NOW() + (INTERVAL '1 second' * POWER(2, retry_count + 1)) -- exponential backoff
           ELSE scheduled_at
         END,
         updated_at = NOW()
       WHERE id = $1`,
      [taskId, error, retryable]
    );

    // Si max retries atteint → DLQ
    const check = await db.query(
      `SELECT status, retry_count, max_retries FROM actions_queue WHERE id = $1`,
      [taskId]
    );
    if (check.rows[0]?.status === 'failed') {
      await this.moveToDLQ(taskId, error);
    }
  }

  // ─── DLQ ────────────────────────────────────────────────────
  private async moveToDLQ(taskId: string, error: string): Promise<void> {
    await db.query(
      `INSERT INTO dead_letter_queue (original_task_id, error_message, failed_at)
       SELECT id, $2, NOW() FROM actions_queue WHERE id = $1
       ON CONFLICT DO NOTHING`,
      [taskId, error]
    );
    logger.warn({ taskId, error }, 'Task moved to DLQ');
  }

  // ─── Heartbeat (évite les tasks bloquées) ───────────────────
  async heartbeat(taskId: string): Promise<void> {
    await db.query(
      `UPDATE actions_queue SET heartbeat_at = NOW() WHERE id = $1`,
      [taskId]
    );
  }

  // ─── Stale tasks recovery (watchdog) ────────────────────────
  async recoverStale(staleAfterMs = 300_000): Promise<number> {
    const result = await db.query(
      `UPDATE actions_queue
       SET status = 'pending', claimed_by = NULL, claimed_at = NULL
       WHERE status = 'claimed'
         AND heartbeat_at < NOW() - ($1 || ' milliseconds')::INTERVAL
       RETURNING id`,
      [staleAfterMs]
    );
    const count = result.rows.length;
    if (count > 0) {
      logger.warn({ count }, 'Recovered stale claimed tasks');
    }
    return count;
  }

  // ─── Poll loop ──────────────────────────────────────────────
  async startPolling(
    taskTypes: string[],
    handler: (task: Task) => Promise<TaskResult>
  ): Promise<void> {
    this.isRunning = true;
    logger.info({ workerId: this.workerId, taskTypes }, 'Claim engine started');

    while (this.isRunning) {
      try {
        const task = await this.claimOne(taskTypes);

        if (!task) {
          await sleep(this.pollIntervalMs);
          continue;
        }

        logger.info({ taskId: task.id, type: task.type, tenantId: task.tenantId }, 'Task claimed');

        // Heartbeat pendant traitement
        const hbInterval = setInterval(() => this.heartbeat(task.id), 30_000);

        try {
          const result = await handler(task);
          clearInterval(hbInterval);

          if (result.success) {
            await this.complete(task.id, result.output);
            logger.info({ taskId: task.id }, 'Task completed');
          } else {
            await this.fail(task.id, result.error ?? 'Unknown error', result.retryable ?? true);
            logger.warn({ taskId: task.id, error: result.error }, 'Task failed');
          }
        } catch (err) {
          clearInterval(hbInterval);
          const msg = err instanceof Error ? err.message : String(err);
          await this.fail(task.id, msg, true);
          logger.error({ taskId: task.id, err: msg }, 'Task handler threw');
        }
      } catch (err) {
        logger.error({ err }, 'Claim engine poll error');
        await sleep(this.pollIntervalMs * 5); // Backoff sur erreur
      }
    }
  }

  stop(): void {
    this.isRunning = false;
    logger.info({ workerId: this.workerId }, 'Claim engine stopped');
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
