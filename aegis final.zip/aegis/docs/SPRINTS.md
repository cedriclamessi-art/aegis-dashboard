# AEGIS — Backlog Sprint 1 + Sprint 2
> 14 jours · Priorité : stabilité + cash conversion + garde-fous

---

## SPRINT 1 — Jours 1–7 : "Foundation Live"
**Objectif : API + DB + Auth + Connectors + Pipeline skeleton opérationnel**

---

### J1 — Infra & Repo

| # | Task | Priorité |
|---|------|----------|
| S1-01 | Init repo monorepo (packages: api, workers, frontend-admin) | P0 |
| S1-02 | Docker Compose prod-ready (postgres, api, worker, nginx) | P0 |
| S1-03 | PostgreSQL 15 : exécuter SQL one-block existants + migrations additionnelles | P0 |
| S1-04 | Variables d'environnement + secrets management (dotenv + vault pattern) | P0 |
| S1-05 | Nginx config (reverse proxy, HTTPS via certbot ou self-signed dev) | P1 |

**Livrable J1**: `docker compose up` → postgres + api alive

---

### J2 — Auth & Multi-Tenant

| # | Task | Priorité |
|---|------|----------|
| S1-06 | Bootstrap admin (env ADMIN_EMAIL + ADMIN_PASSWORD_HASH → seed DB) | P0 |
| S1-07 | POST /auth/login + POST /auth/refresh (JWT 15min + refresh rotation) | P0 |
| S1-08 | Middleware RLS : tenant_id injection sur toutes requêtes | P0 |
| S1-09 | CRUD Tenants : POST /tenants, GET /tenants/:id, PATCH /tenants/:id | P0 |
| S1-10 | Middleware rate limiter (global 1000/min + 100/min/tenant) | P1 |
| S1-11 | Audit log middleware (chaque appel API loggué en DB, append-only) | P1 |

**Livrable J2**: Auth fonctionnel, multi-tenant isolé, admin bootstrapé

---

### J3 — Connector Engine (Core)

| # | Task | Priorité |
|---|------|----------|
| S1-12 | Base connector interface (IConnector) + adapter factory | P0 |
| S1-13 | Token vault (AES-256-GCM encrypt/decrypt + expiry check) | P0 |
| S1-14 | OAuth Manager (PKCE flow + refresh + revoke) | P0 |
| S1-15 | Circuit breaker per-provider (closed/half-open/open) | P0 |
| S1-16 | Connector Registry (register/get/list/health-check) | P0 |
| S1-17 | Shopify Connector v1 (products GET, webhooks receive) | P1 |
| S1-18 | Stripe Connector v1 (subscriptions, trials, webhooks) | P1 |

**Livrable J3**: Shopify + Stripe connectable depuis UI

---

### J4 — Queue & Worker Engine

| # | Task | Priorité |
|---|------|----------|
| S1-19 | Claim engine (SELECT FOR UPDATE SKIP LOCKED, idempotent) | P0 |
| S1-20 | Job dispatcher (agent routing par type de task) | P0 |
| S1-21 | Retry engine (backoff exponentiel x3 puis DLQ) | P0 |
| S1-22 | DLQ table + endpoint GET /admin/dlq + POST /admin/dlq/:id/replay | P0 |
| S1-23 | Watchdog process (health check workers toutes les 60s) | P1 |
| S1-24 | Dead man switch (si 0 task processed en 10min → alert) | P1 |

**Livrable J4**: Queue résiliente, workers qui claim + retry + DLQ

---

### J5 — Pipeline Produit → Assets (skeleton)

| # | Task | Priorité |
|---|------|----------|
| S1-25 | POST /product/ingest {url, tenant_id} → create pipeline_run | P0 |
| S1-26 | PRODUCT_MINER agent skeleton (scrape URL → extract title, desc, price, images) | P0 |
| S1-27 | OFFER_ARCHITECT agent skeleton (structure offre → JSON normalisé) | P0 |
| S1-28 | COPY_LUXE agent (appel LLM → fiche produit luxe + bullets + FAQ) | P0 |
| S1-29 | Asset versioning (hash SHA256 + stockage + versions table) | P1 |
| S1-30 | GET /product/:id/status (pipeline_run statut + étapes) | P1 |

**Livrable J5**: URL produit → fiche luxe générée, status trackable

---

### J6 — Risk Engine + Stop-Loss

| # | Task | Priorité |
|---|------|----------|
| S1-31 | Risk rules table (par tenant + stage : max_loss, roas_min, budget_cap) | P0 |
| S1-32 | RISK_ENGINE agent (évalue métriques toutes les 15min) | P0 |
| S1-33 | Stop-loss auto : pause campaign si ROAS < min | P0 |
| S1-34 | Kill-switch global tenant (POST /risk/kill-switch/{tenant_id}) | P0 |
| S1-35 | Metabolic throttle : si error_rate > 15% → 50% débit workers | P1 |
| S1-36 | Pixel freeze detector : spend sans revenue 2h → alert + freeze | P1 |

**Livrable J6**: Stop-loss opérationnel, kill-switch testé

---

### J7 — Health, Tests & Smoke

| # | Task | Priorité |
|---|------|----------|
| S1-37 | GET /health/live (liveness) + GET /health/ready (readiness) | P0 |
| S1-38 | GET /metrics (Prometheus format : queue depth, agent rates, ROAS) | P0 |
| S1-39 | Tests : saturation queue (10k tasks) | P0 |
| S1-40 | Tests : poison pill retry + DLQ | P0 |
| S1-41 | Tests : kill-switch (stop tous workers tenant) | P0 |
| S1-42 | Tests : budget cap block | P0 |
| S1-43 | Smoke test complet : ingest URL → copy générée → pipeline_run OK | P0 |
| S1-44 | Documentation runbook deploy (VPS → docker up → bootstrap → smoke) | P1 |

**Livrable J7**: Système stable, smoke tests verts, deploy runbook prêt

---

## SPRINT 2 — Jours 8–14 : "Cash Conversion Live"
**Objectif : Ads live · Attribution · Billing · Frontend Admin · Full Pipeline**

---

### J8 — Meta + TikTok Connectors

| # | Task | Priorité |
|---|------|----------|
| S2-01 | Meta Connector v1 : OAuth + Ad Accounts + Campaign CRUD | P0 |
| S2-02 | Meta Connector v1 : Budget update + Pause/Resume + Metrics | P0 |
| S2-03 | TikTok Connector v1 : OAuth + Campaign CRUD + Creative upload | P0 |
| S2-04 | Google Ads Connector v1 : OAuth + Campaigns + Keywords + Reporting | P1 |
| S2-05 | Connector health dashboard (statuts, last ping, error rates) | P1 |

---

### J9 — Media Buying Pipeline

| # | Task | Priorité |
|---|------|----------|
| S2-06 | MEDIA_BUYER agent (propose structure campaign depuis fiche produit) | P0 |
| S2-07 | ADOPS agent (exécute via Meta/TikTok connectors) | P0 |
| S2-08 | BID_OPTIMIZER agent (règles enchères basiques : CBO, budget) | P1 |
| S2-09 | CREATIVE_TESTER agent (matrice A/B créas, suivi fatigue) | P1 |
| S2-10 | Mode Human Control : approval step avant toute launch ads | P0 |

---

### J10 — Attribution + FINOPS

| # | Task | Priorité |
|---|------|----------|
| S2-11 | ATTRIBUTION_AGENT (reconcil spend Meta/TikTok vs revenue Shopify) | P0 |
| S2-12 | ROAS calculé server-side (pas client-side) par adset + campaign | P0 |
| S2-13 | FINOPS_AGENT (marges COGS, seuils rentabilité, alertes) | P1 |
| S2-14 | Dashboard métriques live : spend / revenue / ROAS / marge | P1 |
| S2-15 | Tests : attribution mismatch (spend vs revenue désync) | P0 |

---

### J11 — Billing + Revenue Share

| # | Task | Priorité |
|---|------|----------|
| S2-16 | Plans Stripe : Starter / Pro / Elite / Enterprise | P0 |
| S2-17 | Trial 15 jours (auto-cancel si non converti) | P0 |
| S2-18 | SUBSCRIPTION_AGENT (trial → conversion → churn detection) | P0 |
| S2-19 | Billing ledger interne (chaque transaction loggée) | P0 |
| S2-20 | Revenue share automatique : CA >= 200k€ → 2% via Stripe + ledger | P1 |
| S2-21 | POST /billing/webhook (Stripe events handler) | P0 |

---

### J12 — Frontend Admin v1

| # | Task | Priorité |
|---|------|----------|
| S2-22 | Login page + JWT storage secure | P0 |
| S2-23 | Dashboard home : métriques clés (spend, revenue, ROAS, agents actifs) | P0 |
| S2-24 | Product pipeline view : statut étapes, preview copy, assets | P0 |
| S2-25 | Connector manager : connect/disconnect Meta, TikTok, Shopify, Stripe | P0 |
| S2-26 | Campaign monitor : live metrics + pause/resume manuel | P0 |
| S2-27 | Risk panel : stop-loss config + kill-switch + DLQ | P0 |
| S2-28 | Mode selector : Human / Semi / Full Auto (avec confirmation) | P1 |

---

### J13 — Pipeline End-to-End + Tests de charge

| # | Task | Priorité |
|---|------|----------|
| S2-29 | Workflow complet : URL → copy → ads draft → approval → launch → monitor | P0 |
| S2-30 | Test drift expected/actual (STATE_MANAGER détecte et escalade) | P0 |
| S2-31 | Test rate limit provider (circuit breaker s'ouvre, retry différé) | P0 |
| S2-32 | Test scaling cooldown (scale bloqué si ROAS instable) | P0 |
| S2-33 | Test metabolic throttle (error rate > 15%) | P0 |
| S2-34 | Test full pipeline avec produit réel (mode Human Control) | P0 |

---

### J14 — Hardening + Docs + Go-Live

| # | Task | Priorité |
|---|------|----------|
| S2-35 | Security review : RLS, tokens, JWT, audit log | P0 |
| S2-36 | Runbook final : deploy, bootstrap, connect, smoke, go-live | P0 |
| S2-37 | Doc : "Comment ajouter un connecteur" | P1 |
| S2-38 | Doc : "Comment ajouter un agent" | P1 |
| S2-39 | Doc : "Comment modifier les règles stop-loss" | P1 |
| S2-40 | Checklist sécurité pré-prod (14 points) | P0 |
| S2-41 | Activation Human Control sur premier tenant réel | P0 |
| S2-42 | Go/No-Go checklist : 7 jours green avant Full Auto | P0 |

---

## MÉTRIQUES DE SUCCÈS SPRINT 1 + 2

| Métrique | Seuil Go-Live |
|----------|---------------|
| Smoke tests API | 100% verts |
| Kill-switch latence | < 2s |
| Stop-loss latence | < 15s |
| DLQ replay | Fonctionnel |
| Attribution mismatch détecté | Oui |
| Billing Stripe webhooks | Testés |
| Mode Human Control | Opérationnel |
| Premier produit testé | Au moins 1 |
