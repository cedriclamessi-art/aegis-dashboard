# AEGIS — Structure Repo Complète

```
aegis/
│
├── docker-compose.yml              ← orchestration complète prod
├── docker-compose.dev.yml          ← surcharge dev (hot-reload)
├── .env.example                    ← template variables
├── .gitignore
├── README.md
│
├── infra/
│   ├── nginx/
│   │   ├── nginx.conf              ← reverse proxy + rate limit
│   │   └── ssl/                   ← certs (gitignored)
│   └── docker/
│       ├── Dockerfile.api
│       ├── Dockerfile.worker
│       └── Dockerfile.frontend
│
├── backend/
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── index.ts                ← Fastify server bootstrap
│       │
│       ├── api/
│       │   ├── routes/
│       │   │   ├── auth.routes.ts
│       │   │   ├── tenants.routes.ts
│       │   │   ├── products.routes.ts
│       │   │   ├── campaigns.routes.ts
│       │   │   ├── connectors.routes.ts
│       │   │   ├── billing.routes.ts
│       │   │   ├── agents.routes.ts
│       │   │   ├── risk.routes.ts
│       │   │   └── health.routes.ts
│       │   └── schemas/            ← JSON Schema validation (Fastify)
│       │       ├── auth.schema.ts
│       │       ├── product.schema.ts
│       │       └── ...
│       │
│       ├── middleware/
│       │   ├── authenticate.ts     ← JWT verify + inject user
│       │   ├── rls.ts              ← set app.current_tenant_id
│       │   ├── rate-limit.ts
│       │   └── audit-log.ts       ← append-only log chaque call
│       │
│       ├── services/
│       │   ├── pipeline.service.ts
│       │   ├── billing.service.ts
│       │   ├── connector.service.ts
│       │   ├── risk.service.ts
│       │   ├── attribution.service.ts
│       │   └── auth.service.ts
│       │
│       ├── agents/
│       │   ├── base/
│       │   │   ├── agent.base.ts   ← classe abstraite Agent
│       │   │   └── agent.types.ts
│       │   ├── core/
│       │   │   ├── orchestrator.agent.ts
│       │   │   ├── scheduler.agent.ts
│       │   │   ├── task-router.agent.ts
│       │   │   ├── state-manager.agent.ts
│       │   │   └── audit.agent.ts
│       │   ├── product/
│       │   │   ├── product-miner.agent.ts
│       │   │   ├── offer-architect.agent.ts
│       │   │   ├── copy-luxe.agent.ts
│       │   │   ├── cro-engineer.agent.ts
│       │   │   └── seo.agent.ts
│       │   ├── creative/
│       │   │   ├── creative-director.agent.ts
│       │   │   ├── image-studio.agent.ts
│       │   │   ├── video-studio.agent.ts
│       │   │   ├── ugc-writer.agent.ts
│       │   │   └── brand-guard.agent.ts
│       │   ├── ads/
│       │   │   ├── media-buyer.agent.ts
│       │   │   ├── adops.agent.ts
│       │   │   ├── bid-optimizer.agent.ts
│       │   │   └── creative-tester.agent.ts
│       │   ├── data/
│       │   │   ├── attribution.agent.ts
│       │   │   ├── finops.agent.ts
│       │   │   ├── subscription.agent.ts
│       │   │   └── risk-engine.agent.ts
│       │   ├── health/
│       │   │   ├── sre-healer.agent.ts
│       │   │   └── legal-scraper.agent.ts
│       │   └── plugins/            ← activables par vertical
│       │       ├── innovation.agent.ts
│       │       ├── marketing-psychology.agent.ts
│       │       └── medical-review.agent.ts
│       │
│       ├── connectors/
│       │   ├── base/
│       │   │   ├── connector.interface.ts  ← IConnector
│       │   │   └── adapter.factory.ts
│       │   ├── registry.ts
│       │   ├── token-vault.ts
│       │   ├── oauth-manager.ts
│       │   ├── circuit-breaker.ts
│       │   ├── rate-limiter.ts
│       │   └── providers/
│       │       ├── meta/
│       │       │   ├── meta.connector.ts
│       │       │   └── meta.types.ts
│       │       ├── tiktok/
│       │       │   └── tiktok.connector.ts
│       │       ├── google-ads/
│       │       │   └── google.connector.ts
│       │       ├── shopify/
│       │       │   └── shopify.connector.ts
│       │       └── stripe/
│       │           └── stripe.connector.ts
│       │
│       └── utils/
│           ├── logger.ts           ← structured JSON logs
│           ├── crypto.ts           ← AES-256-GCM helpers
│           ├── retry.ts            ← exponential backoff
│           └── correlation.ts     ← correlation_id propagation
│
├── workers/
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── index.ts                ← worker bootstrap
│       ├── engines/
│       │   ├── claim.engine.ts     ← SELECT FOR UPDATE SKIP LOCKED
│       │   ├── job.engine.ts
│       │   ├── retry.engine.ts
│       │   └── watchdog.ts
│       ├── jobs/
│       │   ├── product-ingest.job.ts
│       │   ├── asset-generation.job.ts
│       │   ├── store-deploy.job.ts
│       │   ├── ads-launch.job.ts
│       │   ├── monitor-roas.job.ts
│       │   └── learn-patterns.job.ts
│       └── queue/
│           ├── publisher.ts
│           ├── consumer.ts
│           └── dlq.ts
│
├── frontend-admin/
│   ├── package.json
│   ├── next.config.js
│   └── src/
│       ├── pages/
│       │   ├── index.tsx           ← dashboard home
│       │   ├── login.tsx
│       │   ├── products/
│       │   │   ├── index.tsx       ← liste pipelines
│       │   │   └── [id].tsx        ← détail pipeline + statut
│       │   ├── campaigns/
│       │   │   └── index.tsx       ← live metrics
│       │   ├── connectors/
│       │   │   └── index.tsx       ← connect/disconnect
│       │   ├── billing/
│       │   │   └── index.tsx       ← plans + ledger
│       │   └── risk/
│       │       └── index.tsx       ← stop-loss config + kill-switch
│       ├── components/
│       │   ├── MetricsCard.tsx
│       │   ├── PipelineStatus.tsx
│       │   ├── ConnectorCard.tsx
│       │   ├── RiskPanel.tsx
│       │   ├── ModeSelector.tsx    ← Human/Semi/Full Auto
│       │   └── KillSwitchButton.tsx
│       └── lib/
│           ├── api.ts              ← fetch wrapper + auth headers
│           └── auth.ts             ← JWT client-side
│
└── migrations/
    ├── 001_base_schema.sql         ← SQL one-block existants
    ├── 002_connector_registry.sql
    ├── 003_token_vault.sql
    ├── 004_billing_ledger.sql
    ├── 005_agent_runtime.sql
    ├── 006_event_bus.sql
    ├── 007_pipeline_runs.sql
    └── 008_asset_versions.sql
```
