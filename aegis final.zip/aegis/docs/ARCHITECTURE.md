# AEGIS — Architecture Finale des Modules
> Version: FINAL / Phase 1 (0→1M) | Build Ready

---

## 1. VUE D'ENSEMBLE SYSTÈME

```
┌─────────────────────────────────────────────────────────────────────┐
│                        AEGIS PLATFORM                               │
│                                                                     │
│  ┌──────────┐    ┌──────────────┐    ┌──────────────────────────┐  │
│  │  Next.js │    │   Fastify    │    │    Worker Cluster        │  │
│  │  Admin   │───▶│   API v1     │───▶│  (claim + job engines)  │  │
│  │  (UI)    │    │  :3000       │    │  :4000                  │  │
│  └──────────┘    └──────┬───────┘    └──────────┬──────────────┘  │
│                         │                       │                  │
│                  ┌──────▼───────────────────────▼──────┐          │
│                  │         PostgreSQL 15+               │          │
│                  │  (RLS · partitions · event bus)      │          │
│                  │  :5432                              │          │
│                  └─────────────────────────────────────┘          │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                  CONNECTOR LAYER                              │  │
│  │  Meta API │ TikTok Ads │ Google Ads │ Shopify │ Stripe       │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2. MODULES PRINCIPAUX

### 2.1 API Backend (Fastify)
```
/backend/src/
  api/
    routes/
      auth.ts          ← login, refresh, bootstrap admin
      tenants.ts       ← CRUD tenants
      products.ts      ← ingest URL, statut pipeline
      campaigns.ts     ← CRUD campaigns, metrics
      connectors.ts    ← OAuth flow, connect/disconnect
      billing.ts       ← plans, subscriptions, revenue share
      agents.ts        ← statut agents, logs, override
      risk.ts          ← stop-loss config, kill-switch
      health.ts        ← liveness, readiness, metrics
    middlewares/
      auth.ts          ← JWT validation
      rls.ts           ← tenant isolation
      rateLimiter.ts   ← global + per-tenant
      audit.ts         ← log tout appel
  services/
    pipeline.service.ts      ← orchestre workflow produit→cash
    billing.service.ts       ← Stripe + revenue share ledger
    connector.service.ts     ← registry + token vault
    risk.service.ts          ← stop-loss rules engine
    attribution.service.ts   ← reconcil spend vs revenue
```

### 2.2 Worker Engine
```
/workers/src/
  engines/
    claim.engine.ts    ← SELECT FOR UPDATE SKIP LOCKED (idempotent)
    job.engine.ts      ← dispatche tasks aux agents
    retry.engine.ts    ← backoff exponentiel + DLQ
    watchdog.ts        ← deadman switch + health monitor
  jobs/
    product-ingest.job.ts
    asset-generation.job.ts
    store-deploy.job.ts
    ads-launch.job.ts
    monitor-roas.job.ts
    learn-patterns.job.ts
  queue/
    publisher.ts
    consumer.ts
    dlq.ts
```

### 2.3 Agent System (25 agents)
```
/backend/src/agents/
  core/
    orchestrator.agent.ts    ← planification pipeline
    scheduler.agent.ts       ← cron + fenêtres temporelles
    task-router.agent.ts     ← routing + priorités
    state-manager.agent.ts   ← expected vs actual
    audit.agent.ts           ← traçabilité immuable
  product/
    product-miner.agent.ts   ← scraping + extraction
    offer-architect.agent.ts ← angle + offre + bundles
    copy-luxe.agent.ts       ← fiche luxe + FAQ + hooks
    cro-engineer.agent.ts    ← structure page + sections
    seo.agent.ts             ← sémantique + schema
  creative/
    creative-director.agent.ts
    image-studio.agent.ts    ← provider-agnostic
    video-studio.agent.ts    ← scripts + montage
    ugc-writer.agent.ts
    brand-guard.agent.ts
  ads/
    media-buyer.agent.ts     ← stratégie + structure
    adops.agent.ts           ← implémentation connectors
    bid-optimizer.agent.ts
    creative-tester.agent.ts
  data/
    attribution.agent.ts
    finops.agent.ts
    subscription.agent.ts
    risk-engine.agent.ts     ← stop-loss + kill-switch
  health/
    sre-healer.agent.ts      ← auto-repair
    legal-scraper.agent.ts   ← robots.txt + ToS + consent
  plugins/                   ← activables par vertical
    innovation.agent.ts
    marketing-psychology.agent.ts
    medical-review.agent.ts
```

### 2.4 Connector Engine
```
/backend/src/connectors/
  registry.ts          ← ConnectorRegistry (add/remove/list)
  token-vault.ts       ← chiffrement AES-256-GCM + rotation
  oauth-manager.ts     ← PKCE + refresh + revoke
  circuit-breaker.ts   ← per-provider CB (half-open/open/closed)
  rate-limiter.ts      ← per-provider + per-tenant
  providers/
    meta/
      meta.connector.ts
      meta.types.ts
    tiktok/
      tiktok.connector.ts
    google-ads/
      google.connector.ts
    shopify/
      shopify.connector.ts
    stripe/
      stripe.connector.ts
    _base/
      base.connector.ts    ← interface IConnector (obligatoire)
      adapter.factory.ts   ← swap providers sans breaking change
```

### 2.5 Risk & Stop-Loss Engine
```
Risk Rules (par tenant + stage):
  ┌──────────────────────────────────────────────────────────┐
  │ Stage     │ Max Loss/Day │ ROAS Min │ Budget Cap/Adset   │
  ├──────────────────────────────────────────────────────────┤
  │ Seed      │ 500€         │ 1.5      │ 50€/j              │
  │ 1M        │ 2000€        │ 2.0      │ 500€/j             │
  │ 10M       │ 10k€         │ 2.5      │ 5k€/j              │
  │ 100M      │ 50k€         │ 3.0      │ configurable       │
  └──────────────────────────────────────────────────────────┘
  
  Triggers automatiques:
  - ROAS < min → pause immédiate + alert
  - Erreurs > 15% → metabolic throttle (50% débit)
  - Pixel HS (spend sans revenue 2h) → freeze + alerte
  - Kill-switch global → stop all workers pour tenant
  - Drift expected/actual > 20% → escalade STATE_MANAGER
```

### 2.6 Data Model (tables additionnelles)
```sql
-- En plus des SQL one-block existants:
connector_registry      ← providers + config + status
token_vault            ← tokens chiffrés + expiry + rotation
oauth_states           ← PKCE flow states
billing_ledger         ← transactions + revenue share log
revenue_share_events   ← seuil 200k€ → 2%
agent_runtime_log      ← chaque action agent (immuable)
event_bus              ← messages inter-agents
pipeline_runs          ← run complet URL→cash + statut
asset_versions         ← hash + versions des créas
```

---

## 3. MODES DE CONTRÔLE

```
HUMAN CONTROL:
  - Chaque étape → notification + approval requis
  - Timeout 24h → escalade admin
  - 0 action auto sauf monitoring

SEMI CONTROL:
  - Auto jusqu'aux actions "risque élevé" (spend > seuil, launch ads)
  - Approval requis pour: première launch, scaling > 2x, changement offre
  - Stop-loss 100% automatique (pas d'approbation nécessaire)

FULL AUTO:
  - Tout automatique
  - Stop-loss + kill-switch toujours actifs
  - Report quotidien obligatoire
  - Activable seulement après 7 jours "green" validés
```

---

## 4. SÉCURITÉ — PRINCIPES NON NÉGOCIABLES

- JWT short-lived (15min) + refresh token rotation
- RLS PostgreSQL sur TOUTES les tables (tenant_id)
- Tokens connectors : AES-256-GCM + vault séparé
- Audit log append-only (no UPDATE/DELETE)
- Rate limiting : global 1000 req/min + 100/min/tenant
- Secrets via env vars uniquement (jamais en DB en clair)
- Circuit breaker par provider (évite cascade failures)
- Health endpoints sans auth (pour load balancer)

---

## 5. OBSERVABILITÉ

```
Logs structurés (JSON) → stdout → agrégateur (Loki / CloudWatch)
Metrics : /metrics endpoint (Prometheus format)
  - queue depth
  - agent success/failure rate
  - spend vs ROAS temps réel
  - connector latency
  - stop-loss triggers count
Tracing : correlation_id sur chaque request → propagé dans workers
Alerting : seuils sur ROAS, erreurs, budget, health
```

---

## 6. DOCTRINE SCALING

```
0 → 1M€:    1 VPS, Docker Compose, 2 workers
1M → 10M€:  2 VPS, 4-8 workers, read replica DB
10M → 100M: k8s, workers autoscale, DB sharding, CDN assets
```
