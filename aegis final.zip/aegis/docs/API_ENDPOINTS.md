# AEGIS — Endpoints API Minimum (v1)
> Fastify · REST · JSON · JWT Bearer Auth (sauf /health + /auth)

---

## AUTH

| Method | Endpoint | Body | Response |
|--------|----------|------|----------|
| POST | `/v1/auth/login` | `{email, password}` | `{access_token, refresh_token, tenant_id}` |
| POST | `/v1/auth/refresh` | `{refresh_token}` | `{access_token}` |
| POST | `/v1/auth/logout` | — | `{ok: true}` |

---

## HEALTH (sans auth)

| Method | Endpoint | Response |
|--------|----------|----------|
| GET | `/health/live` | `{status: "ok"}` |
| GET | `/health/ready` | `{db: "ok", workers: "ok", queue_depth: 0}` |
| GET | `/metrics` | Prometheus text format |

---

## TENANTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/v1/tenants` | Créer tenant (admin only) |
| GET | `/v1/tenants/:id` | Détail tenant |
| PATCH | `/v1/tenants/:id` | Update (plan, mode, config) |
| GET | `/v1/tenants/:id/usage` | Usage courant (spend, calls, agents) |

---

## PRODUCTS / PIPELINE

| Method | Endpoint | Body / Params | Description |
|--------|----------|---------------|-------------|
| POST | `/v1/products/ingest` | `{url, mode?, options?}` | Lance pipeline complet |
| GET | `/v1/products` | `?page&limit&status` | Liste pipelines tenant |
| GET | `/v1/products/:id` | — | Détail pipeline run |
| GET | `/v1/products/:id/status` | — | Statut étapes temps réel |
| GET | `/v1/products/:id/assets` | — | Assets générés (copy, images, vidéos) |
| POST | `/v1/products/:id/approve` | `{step, decision}` | Approval Human Control |
| POST | `/v1/products/:id/pause` | — | Pause pipeline |
| POST | `/v1/products/:id/cancel` | — | Annule pipeline |

**Status flow:**
```
PENDING → MINING → COPY_GENERATION → ASSET_CREATION → 
STORE_DEPLOY → ADS_DRAFT → [APPROVAL?] → ADS_LIVE → 
MONITORING → SCALING / PAUSED / STOPPED
```

---

## CAMPAIGNS

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| GET | `/v1/campaigns` | — | Liste campaigns tenant |
| GET | `/v1/campaigns/:id` | — | Détail + métriques live |
| GET | `/v1/campaigns/:id/metrics` | `?from&to&granularity` | ROAS, spend, revenue, CPA |
| PATCH | `/v1/campaigns/:id` | `{budget?, status?}` | Update budget / pause |
| POST | `/v1/campaigns/:id/pause` | — | Pause immédiate |
| POST | `/v1/campaigns/:id/resume` | — | Reprendre |
| POST | `/v1/campaigns/:id/scale` | `{multiplier}` | Scale budget (si ROAS OK) |

---

## CONNECTORS

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| GET | `/v1/connectors` | — | Liste connecteurs + statuts |
| GET | `/v1/connectors/:provider` | — | Détail + health |
| POST | `/v1/connectors/:provider/oauth/init` | — | Lance OAuth flow (→ redirect_url) |
| GET | `/v1/connectors/:provider/oauth/callback` | `?code&state` | OAuth callback |
| DELETE | `/v1/connectors/:provider` | — | Déconnecter + révoquer tokens |
| POST | `/v1/connectors/:provider/test` | — | Test connexion (ping API) |

**Providers:** `meta` · `tiktok` · `google-ads` · `shopify` · `stripe`

---

## BILLING

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| GET | `/v1/billing/plans` | — | Liste plans disponibles |
| GET | `/v1/billing/subscription` | — | Abo courant tenant |
| POST | `/v1/billing/subscribe` | `{plan_id}` | Créer subscription (→ Stripe) |
| POST | `/v1/billing/cancel` | — | Annuler abo (end of period) |
| GET | `/v1/billing/ledger` | `?page&limit` | Historique transactions |
| GET | `/v1/billing/revenue-share` | — | Statut revenue share (seuil 200k) |
| POST | `/v1/billing/webhook` | Stripe event | Webhook Stripe (sans auth JWT) |

---

## AGENTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/agents` | Liste agents + statut (idle/running/error) |
| GET | `/v1/agents/:name/logs` | Logs récents agent |
| POST | `/v1/agents/:name/restart` | Restart agent (admin) |
| PATCH | `/v1/agents/:name/config` | Override config agent |

---

## RISK / STOP-LOSS

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| GET | `/v1/risk/config` | — | Config stop-loss tenant |
| PATCH | `/v1/risk/config` | `{roas_min, max_loss_day, budget_cap}` | Modifier règles |
| GET | `/v1/risk/events` | — | Historique triggers stop-loss |
| POST | `/v1/risk/kill-switch` | `{confirm: true}` | Kill-switch global tenant |
| DELETE | `/v1/risk/kill-switch` | — | Lever le kill-switch |
| GET | `/v1/risk/mode` | — | Mode actuel (human/semi/auto) |
| PATCH | `/v1/risk/mode` | `{mode}` | Changer mode (semi/auto require confirmation) |

---

## QUEUE / DLQ (admin)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/v1/admin/queue/stats` | Depth, processing rate, lag |
| GET | `/v1/admin/dlq` | Messages en DLQ |
| POST | `/v1/admin/dlq/:id/replay` | Rejouer message DLQ |
| DELETE | `/v1/admin/dlq/:id` | Supprimer message DLQ |

---

## CODES D'ERREUR STANDARD

```json
{
  "error": "ROAS_BELOW_MINIMUM",
  "message": "Campaign paused: ROAS 1.2 below threshold 2.0",
  "code": 422,
  "correlation_id": "req_abc123",
  "tenant_id": "ten_xyz"
}
```

| Code | Signification |
|------|---------------|
| 400 | Validation schema échouée |
| 401 | Token manquant ou expiré |
| 403 | RLS — accès refusé (autre tenant) |
| 404 | Ressource non trouvée |
| 409 | Conflit état (ex: campaign déjà active) |
| 422 | Règle métier violée (stop-loss, budget cap) |
| 429 | Rate limit dépassé |
| 503 | Circuit breaker ouvert (provider down) |

---

## SÉCURITÉ ENDPOINTS

```
Auth         : Bearer JWT (15min) sur toutes routes /v1/*
Exception    : /health/*, /metrics, /v1/auth/*, /v1/billing/webhook
Rate limit   : X-RateLimit-Limit / X-RateLimit-Remaining headers
Tenant       : X-Tenant-ID injecté par middleware RLS
Correlation  : X-Correlation-ID propagé request→worker→logs
Audit        : TOUS les appels écrits en DB (append-only)
```

---

## WEBHOOK ENDPOINTS (entrants)

| Provider | Endpoint | Events |
|----------|----------|--------|
| Stripe | `POST /v1/billing/webhook` | invoice.paid, subscription.updated, customer.subscription.deleted |
| Shopify | `POST /v1/connectors/shopify/webhook` | orders/create, products/update |
| Meta | `POST /v1/connectors/meta/webhook` | Ad insights updates |
