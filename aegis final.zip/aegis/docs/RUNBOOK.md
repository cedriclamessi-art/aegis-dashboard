# AEGIS — Runbook Deploy + Checklist Sécurité

---

## 1. DEPLOY RUNBOOK (VPS → Production)

### Prérequis
```bash
# VPS minimum recommandé Phase 1:
# CPU: 4 vCPU / RAM: 8 GB / Storage: 50 GB SSD
# OS: Ubuntu 22.04 LTS
# Ports ouverts: 80, 443, 22 (SSH)

# Outils requis sur le serveur:
sudo apt update && sudo apt install -y docker.io docker-compose-v2 git openssl
```

### Étape 1 — Clone + Config
```bash
git clone https://github.com/your-org/aegis.git /opt/aegis
cd /opt/aegis
cp .env.example .env
```

### Étape 2 — Générer les secrets
```bash
# JWT secrets
echo "JWT_SECRET=$(openssl rand -hex 64)" >> .env
echo "JWT_REFRESH_SECRET=$(openssl rand -hex 64)" >> .env

# Vault encryption key (32 bytes = 64 hex chars)
echo "VAULT_KEY=$(openssl rand -hex 32)" >> .env

# Admin password hash (bcrypt)
# node -e "console.log(require('bcryptjs').hashSync('your_password', 12))"
echo "ADMIN_EMAIL=admin@yourdomain.com" >> .env
echo "ADMIN_PASSWORD_HASH=<bcrypt_hash>" >> .env

# DB
echo "POSTGRES_PASSWORD=$(openssl rand -hex 32)" >> .env
```

### Étape 3 — SSL (Let's Encrypt)
```bash
# Option A: Certbot standalone
sudo certbot certonly --standalone -d yourdomain.com
sudo cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem ./infra/nginx/ssl/
sudo cp /etc/letsencrypt/live/yourdomain.com/privkey.pem ./infra/nginx/ssl/

# Option B: Self-signed pour dev
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout ./infra/nginx/ssl/privkey.pem \
  -out ./infra/nginx/ssl/fullchain.pem \
  -subj "/CN=localhost"
```

### Étape 4 — Build + Start
```bash
cd /opt/aegis
docker compose build --no-cache
docker compose up -d

# Vérifier que tout est up
docker compose ps
docker compose logs api --tail=50
docker compose logs worker --tail=50
```

### Étape 5 — Init DB
```bash
# Les migrations s'exécutent automatiquement au démarrage PostgreSQL
# Vérifier:
docker compose exec postgres psql -U aegis -c "\dt"
# Doit afficher toutes les tables AEGIS
```

### Étape 6 — Bootstrap Admin
```bash
# L'admin est créé automatiquement au démarrage de l'API
# via ADMIN_EMAIL + ADMIN_PASSWORD_HASH dans .env
# Vérifier:
curl http://localhost:3000/health/ready
# {"db":"ok","workers":"ok","queue_depth":0}
```

### Étape 7 — Smoke Tests
```bash
# 1. Health
curl https://yourdomain.com/health/live
# {"status":"ok"}

# 2. Login admin
TOKEN=$(curl -s -X POST https://yourdomain.com/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@yourdomain.com","password":"your_password"}' \
  | jq -r '.access_token')

# 3. List tenants
curl https://yourdomain.com/v1/tenants \
  -H "Authorization: Bearer $TOKEN"

# 4. Health metrics
curl https://yourdomain.com/metrics

# 5. Test kill-switch (puis lever)
curl -X POST https://yourdomain.com/v1/risk/kill-switch \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"confirm":true}'
curl -X DELETE https://yourdomain.com/v1/risk/kill-switch \
  -H "Authorization: Bearer $TOKEN"
```

### Étape 8 — Connecter les providers
```bash
# Via l'interface admin:
# 1. Shopify → /connectors → "Connect Shopify" → OAuth
# 2. Stripe → /connectors → "Connect Stripe" → API Key
# 3. Meta → /connectors → "Connect Meta" → OAuth (optionnel phase 1)

# Ou via API:
curl -X POST https://yourdomain.com/v1/connectors/shopify/oauth/init \
  -H "Authorization: Bearer $TOKEN"
# Retourne {redirect_url: "..."} → ouvrir dans browser
```

### Étape 9 — Premier produit test
```bash
curl -X POST https://yourdomain.com/v1/products/ingest \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://your-shopify-store.myshopify.com/products/test-product", "mode": "human"}'
# {"pipeline_run_id": "...", "status": "pending"}

# Suivre le statut
curl https://yourdomain.com/v1/products/{pipeline_run_id}/status \
  -H "Authorization: Bearer $TOKEN"
```

### Étape 10 — Activer modes progressivement
```bash
# Jour 0-7: Human Control uniquement (approval obligatoire à chaque étape)
# Jour 7+: Passer en Semi Control si tout est green
# Jour 14+: Full Auto seulement si métriques stables 7 jours

curl -X PATCH https://yourdomain.com/v1/risk/mode \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"mode": "semi"}'
```

---

## 2. CHECKLIST SÉCURITÉ PRÉ-PROD (14 points)

### Secrets & Auth
- [ ] JWT_SECRET ≥ 64 chars random hex (jamais en dur dans le code)
- [ ] VAULT_KEY = 64 chars hex (AES-256), backup sécurisé offline
- [ ] ADMIN_PASSWORD_HASH = bcrypt round 12 minimum
- [ ] POSTGRES_PASSWORD = random 32+ chars
- [ ] Tous les secrets via .env (jamais committé, .gitignore vérifié)

### Database
- [ ] RLS activé sur TOUTES les tables avec tenant_id
- [ ] Audit log append-only (pas de permission UPDATE/DELETE sur audit tables)
- [ ] Connexion DB interne uniquement (pas de port exposé au public)
- [ ] Backup automatique configuré (pg_dump cron journalier minimum)

### API & Réseau
- [ ] HTTPS obligatoire (HTTP → redirect 301)
- [ ] Rate limiting actif (global + per-tenant)
- [ ] CORS configuré strictement (CORS_ORIGINS = domaine précis)
- [ ] Health endpoints /health/* sans auth (mais limités en info)

### Connectors
- [ ] Tokens never logged (vérifier que token_vault chiffre avant INSERT)
- [ ] Circuit breaker actif sur chaque provider
- [ ] Webhook endpoints : signature vérifiée (Stripe: Stripe-Signature, Shopify: HMAC)

---

## 3. COMMENT AJOUTER UN CONNECTEUR

```typescript
// 1. Créer /backend/src/connectors/providers/mon-provider/mon-provider.connector.ts
// 2. Implémenter IConnector (toutes les méthodes obligatoires)

import { IConnector, ConnectorConfig, AdCampaign, ... } from '../../base/connector.interface';
import { tokenVault } from '../../token-vault';
import { circuitBreaker } from '../../circuit-breaker';

export class MonProviderConnector implements IConnector {
  readonly provider = 'mon_provider';
  config!: ConnectorConfig;

  async initialize(config: ConnectorConfig): Promise<void> {
    this.config = config;
  }

  async healthCheck() {
    return circuitBreaker.execute(this.config.tenantId, this.provider, async () => {
      const token = await tokenVault.retrieve(this.config.tenantId, this.provider, 'access_token');
      // ping API provider...
      return { status: 'healthy', lastCheckedAt: new Date() };
    });
  }

  // ... implémenter les autres méthodes
}

// 3. Enregistrer dans AdapterFactory
AdapterFactory.register('mon_provider', MonProviderConnector);

// 4. Ajouter OAuth flow dans oauth-manager.ts si nécessaire
// 5. Ajouter route webhook dans connectors.routes.ts si nécessaire
```

---

## 4. COMMENT AJOUTER UN AGENT

```typescript
// 1. Créer /backend/src/agents/{category}/mon-agent.agent.ts
// 2. Étendre AgentBase

import { AgentBase, AgentTask, AgentResult } from '../base/agent.base';

export class MonAgent extends AgentBase {
  readonly name = 'MON_AGENT';
  readonly taskTypes = ['mon_agent.tache_a', 'mon_agent.tache_b'];

  async execute(task: AgentTask): Promise<AgentResult> {
    switch (task.type) {
      case 'mon_agent.tache_a':
        return this.handleTacheA(task);
      default:
        return { success: false, error: `Unknown task type: ${task.type}` };
    }
  }

  private async handleTacheA(task: AgentTask): Promise<AgentResult> {
    // logique métier
    // Publier vers event_bus si besoin:
    await this.emit('mon_agent.tache_a.completed', { result: '...' }, task);
    return { success: true, output: { result: '...' } };
  }
}

// 3. Enregistrer dans job.engine.ts
// 4. Ajouter les task_types dans actions_queue (migrations si besoin)
```

---

## 5. COMMENT MODIFIER LES RÈGLES STOP-LOSS

### Via API (recommandé)
```bash
curl -X PATCH https://yourdomain.com/v1/risk/config \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "roas_min": 2.5,
    "max_loss_day": 1000,
    "budget_cap_adset": 100,
    "cooldown_minutes": 90,
    "error_rate_threshold_pct": 10,
    "pixel_freeze_minutes": 90
  }'
```

### Via DB (admin direct)
```sql
UPDATE tenants
SET risk_config = risk_config || '{
  "roas_min": 2.5,
  "max_loss_day": 1000
}'::jsonb
WHERE id = 'tenant_uuid';
```

### Règles par stage (défaults)
| Stage | ROAS min | Max loss/j | Budget cap/adset |
|-------|----------|-----------|-----------------|
| Seed (< 10k€/mois) | 1.5 | 500€ | 50€ |
| Growth (< 100k€/mois) | 2.0 | 2000€ | 500€ |
| Scale (< 1M€/mois) | 2.5 | 10k€ | 5k€ |
| Enterprise (> 1M€/mois) | 3.0 | 50k€ | configurable |

> ⚠️ Tout changement stop-loss est loggué dans risk_events (immuable)
> ⚠️ Ne jamais désactiver le kill-switch global sans validation admin
