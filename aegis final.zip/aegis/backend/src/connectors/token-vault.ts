// ============================================================
// AEGIS — Token Vault
// Chiffrement AES-256-GCM · Rotation · Jamais en clair
// ============================================================

import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';
import { db } from '../utils/db';

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16;

export class TokenVault {
  private readonly encryptionKey: Buffer;

  constructor() {
    const keyHex = process.env.VAULT_KEY;
    if (!keyHex || keyHex.length !== 64) {
      throw new Error('VAULT_KEY must be 64 hex chars (32 bytes). Generate with: openssl rand -hex 32');
    }
    this.encryptionKey = Buffer.from(keyHex, 'hex');
  }

  // ─── Encrypt ────────────────────────────────────────────────
  private encrypt(plaintext: string): { iv: Buffer; authTag: Buffer; encrypted: Buffer } {
    const iv = randomBytes(IV_LENGTH);
    const cipher = createCipheriv(ALGORITHM, this.encryptionKey, iv);
    const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const authTag = cipher.getAuthTag();
    return { iv, authTag, encrypted };
  }

  // ─── Decrypt ────────────────────────────────────────────────
  private decrypt(encrypted: Buffer, iv: Buffer, authTag: Buffer): string {
    const decipher = createDecipheriv(ALGORITHM, this.encryptionKey, iv);
    decipher.setAuthTag(authTag);
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
  }

  // ─── Store token ────────────────────────────────────────────
  async store(
    tenantId: string,
    provider: string,
    tokenType: 'access_token' | 'refresh_token' | 'api_key',
    value: string,
    expiresAt?: Date
  ): Promise<void> {
    const { iv, authTag, encrypted } = this.encrypt(value);

    // Désactiver les anciens tokens du même type
    await db.query(
      `UPDATE token_vault 
       SET is_active = false 
       WHERE tenant_id = $1 AND provider = $2 AND token_type = $3 AND is_active = true`,
      [tenantId, provider, tokenType]
    );

    await db.query(
      `INSERT INTO token_vault 
       (tenant_id, provider, token_type, encrypted_value, iv, auth_tag, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [tenantId, provider, tokenType, encrypted, iv, authTag, expiresAt ?? null]
    );
  }

  // ─── Retrieve token ─────────────────────────────────────────
  async retrieve(
    tenantId: string,
    provider: string,
    tokenType: 'access_token' | 'refresh_token' | 'api_key'
  ): Promise<string | null> {
    const result = await db.query(
      `SELECT encrypted_value, iv, auth_tag, expires_at
       FROM token_vault
       WHERE tenant_id = $1 AND provider = $2 AND token_type = $3 AND is_active = true
       ORDER BY created_at DESC LIMIT 1`,
      [tenantId, provider, tokenType]
    );

    if (result.rows.length === 0) return null;

    const { encrypted_value, iv, auth_tag, expires_at } = result.rows[0];

    // Vérifier expiry
    if (expires_at && new Date(expires_at) < new Date()) {
      return null; // Token expiré
    }

    return this.decrypt(encrypted_value, iv, auth_tag);
  }

  // ─── Check if token exists + valid ──────────────────────────
  async isValid(tenantId: string, provider: string, tokenType: 'access_token' | 'refresh_token' | 'api_key'): Promise<boolean> {
    const result = await db.query(
      `SELECT id FROM token_vault
       WHERE tenant_id = $1 AND provider = $2 AND token_type = $3 AND is_active = true
         AND (expires_at IS NULL OR expires_at > NOW())
       LIMIT 1`,
      [tenantId, provider, tokenType]
    );
    return result.rows.length > 0;
  }

  // ─── Revoke all tokens for provider ─────────────────────────
  async revoke(tenantId: string, provider: string): Promise<void> {
    await db.query(
      `UPDATE token_vault SET is_active = false
       WHERE tenant_id = $1 AND provider = $2`,
      [tenantId, provider]
    );
  }

  // ─── Update rotation timestamp ───────────────────────────────
  async markRotated(tenantId: string, provider: string): Promise<void> {
    await db.query(
      `UPDATE token_vault SET last_rotated_at = NOW()
       WHERE tenant_id = $1 AND provider = $2 AND is_active = true`,
      [tenantId, provider]
    );
  }
}

export const tokenVault = new TokenVault();
