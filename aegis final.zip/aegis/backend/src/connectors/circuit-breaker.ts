// ============================================================
// AEGIS — Circuit Breaker (per provider)
// States: CLOSED → OPEN → HALF_OPEN → CLOSED
// ============================================================

import { logger } from '../utils/logger';

export type CircuitState = 'closed' | 'half_open' | 'open';

interface CircuitBreakerOptions {
  failureThreshold?: number;     // nb d'échecs avant OPEN (default: 5)
  recoveryTimeMs?: number;       // ms avant tentative HALF_OPEN (default: 60s)
  successThreshold?: number;     // succès HALF_OPEN requis pour CLOSED (default: 2)
  timeoutMs?: number;            // timeout per call (default: 10s)
}

interface CircuitStats {
  state: CircuitState;
  failures: number;
  successes: number;
  lastFailureAt?: Date;
  openedAt?: Date;
  provider: string;
}

export class CircuitBreaker {
  private circuits = new Map<string, CircuitStats>();

  private getKey(tenantId: string, provider: string): string {
    return `${tenantId}:${provider}`;
  }

  private getCircuit(key: string, provider: string): CircuitStats {
    if (!this.circuits.has(key)) {
      this.circuits.set(key, { state: 'closed', failures: 0, successes: 0, provider });
    }
    return this.circuits.get(key)!;
  }

  // ─── Wrapper principal ──────────────────────────────────────
  async execute<T>(
    tenantId: string,
    provider: string,
    fn: () => Promise<T>,
    options: CircuitBreakerOptions = {}
  ): Promise<T> {
    const {
      failureThreshold = 5,
      recoveryTimeMs = 60_000,
      successThreshold = 2,
      timeoutMs = 10_000,
    } = options;

    const key = this.getKey(tenantId, provider);
    const circuit = this.getCircuit(key, provider);

    // OPEN → vérifier si délai écoulé
    if (circuit.state === 'open') {
      const elapsed = circuit.openedAt ? Date.now() - circuit.openedAt.getTime() : Infinity;
      if (elapsed < recoveryTimeMs) {
        throw new CircuitOpenError(provider, Math.round((recoveryTimeMs - elapsed) / 1000));
      }
      // Passer en HALF_OPEN pour tenter
      circuit.state = 'half_open';
      circuit.successes = 0;
      logger.info({ provider, tenantId }, 'Circuit breaker: HALF_OPEN — testing recovery');
    }

    // Exécuter avec timeout
    try {
      const result = await Promise.race([
        fn(),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Provider ${provider} timeout after ${timeoutMs}ms`)), timeoutMs)
        ),
      ]);

      // Succès
      if (circuit.state === 'half_open') {
        circuit.successes++;
        if (circuit.successes >= successThreshold) {
          circuit.state = 'closed';
          circuit.failures = 0;
          logger.info({ provider, tenantId }, 'Circuit breaker: CLOSED — provider recovered');
        }
      } else {
        circuit.failures = 0; // Reset sur succès en CLOSED
      }

      return result;
    } catch (err) {
      // Échec
      circuit.failures++;
      circuit.lastFailureAt = new Date();

      if (circuit.state === 'half_open' || circuit.failures >= failureThreshold) {
        circuit.state = 'open';
        circuit.openedAt = new Date();
        logger.error({ provider, tenantId, failures: circuit.failures }, 'Circuit breaker: OPEN — provider failing');
      }

      throw err;
    }
  }

  getState(tenantId: string, provider: string): CircuitStats {
    return this.getCircuit(this.getKey(tenantId, provider), provider);
  }

  forceClose(tenantId: string, provider: string): void {
    const key = this.getKey(tenantId, provider);
    const circuit = this.getCircuit(key, provider);
    circuit.state = 'closed';
    circuit.failures = 0;
    circuit.successes = 0;
  }
}

export class CircuitOpenError extends Error {
  constructor(public readonly provider: string, public readonly retryInSeconds: number) {
    super(`Circuit OPEN for provider "${provider}". Retry in ${retryInSeconds}s.`);
    this.name = 'CircuitOpenError';
  }
}

// Singleton
export const circuitBreaker = new CircuitBreaker();
