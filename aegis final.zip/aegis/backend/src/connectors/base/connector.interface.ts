// ============================================================
// AEGIS — IConnector (interface obligatoire pour tout provider)
// Tout nouveau connecteur DOIT implémenter cette interface
// ============================================================

export interface ConnectorConfig {
  provider: string;
  tenantId: string;
  accountId?: string;
  [key: string]: unknown;
}

export interface ConnectorHealth {
  status: 'healthy' | 'degraded' | 'down';
  latencyMs?: number;
  lastCheckedAt: Date;
  errorMessage?: string;
}

export interface AdCampaign {
  id: string;
  name: string;
  status: 'ACTIVE' | 'PAUSED' | 'DELETED';
  dailyBudget: number;
  currency: string;
  objective: string;
  metrics?: CampaignMetrics;
}

export interface CampaignMetrics {
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  roas: number;
  cpa: number;
  from: Date;
  to: Date;
}

export interface CreateCampaignPayload {
  name: string;
  objective: string;
  dailyBudget: number;
  adsets: AdsetPayload[];
}

export interface AdsetPayload {
  name: string;
  targeting: Record<string, unknown>;
  ads: AdPayload[];
}

export interface AdPayload {
  name: string;
  creative: {
    imageUrl?: string;
    videoUrl?: string;
    headline: string;
    body: string;
    callToAction: string;
    landingUrl: string;
  };
}

// ============================================================
// Interface principale — TOUT connecteur doit l'implémenter
// ============================================================
export interface IConnector {
  readonly provider: string;
  readonly config: ConnectorConfig;

  // Lifecycle
  initialize(config: ConnectorConfig): Promise<void>;
  healthCheck(): Promise<ConnectorHealth>;
  disconnect(): Promise<void>;

  // Campaigns
  listCampaigns(): Promise<AdCampaign[]>;
  getCampaign(id: string): Promise<AdCampaign>;
  createCampaign(payload: CreateCampaignPayload): Promise<AdCampaign>;
  updateCampaign(id: string, updates: Partial<AdCampaign>): Promise<AdCampaign>;
  pauseCampaign(id: string): Promise<void>;
  resumeCampaign(id: string): Promise<void>;
  deleteCampaign(id: string): Promise<void>;

  // Budget
  updateBudget(campaignId: string, dailyBudget: number): Promise<void>;
  scaleBudget(campaignId: string, multiplier: number): Promise<void>;

  // Metrics
  getMetrics(campaignId: string, from: Date, to: Date): Promise<CampaignMetrics>;

  // Creatives (optionnel selon provider)
  uploadCreative?(creative: AdPayload['creative']): Promise<{ id: string; url: string }>;
}

// ============================================================
// AdapterFactory — swap provider sans breaking change
// ============================================================
import { MetaConnector } from '../providers/meta/meta.connector';
import { TikTokConnector } from '../providers/tiktok/tiktok.connector';
import { GoogleAdsConnector } from '../providers/google-ads/google.connector';

export class AdapterFactory {
  private static registry = new Map<string, new () => IConnector>([
    ['meta', MetaConnector],
    ['tiktok', TikTokConnector],
    ['google_ads', GoogleAdsConnector],
  ]);

  static create(provider: string): IConnector {
    const ConnectorClass = this.registry.get(provider);
    if (!ConnectorClass) {
      throw new Error(`Connector not registered: ${provider}. Available: ${[...this.registry.keys()].join(', ')}`);
    }
    return new ConnectorClass();
  }

  // Ajouter un nouveau connecteur au runtime
  static register(provider: string, ConnectorClass: new () => IConnector): void {
    this.registry.set(provider, ConnectorClass);
  }

  static list(): string[] {
    return [...this.registry.keys()];
  }
}
