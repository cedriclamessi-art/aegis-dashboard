// ============================================================
// AEGIS — RISK_ENGINE Agent
// Stop-loss · Kill-switch · Metabolic throttle · Pixel freeze
// ============================================================

import { db } from '../../utils/db';
import { logger } from '../../utils/logger';

interface RiskConfig {
  roasMin: number;
  maxLossPerDay: number;
  budgetCapPerAdset: number;
  cooldownMinutes: number;
  errorRateThresholdPct: number;
  pixelFreezeSuspendMinutes: number;
}

interface StopLossEvaluation {
  action: 'none' | 'pause_campaign' | 'freeze_tenant' | 'metabolic_throttle' | 'pixel_freeze';
  reason?: string;
  campaignId?: string;
  tenantId?: string;
  metricValue?: number;
  threshold?: number;
}

export class RiskEngineAgent {
  readonly name = 'RISK_ENGINE';

  // ─── Évaluation principale (appelée toutes les 15min) ───────
  async evaluate(tenantId: string): Promise<StopLossEvaluation[]> {
    const actions: StopLossEvaluation[] = [];
    const config = await this.getConfig(tenantId);

    // 1. ROAS check par campaign
    const roasEvals = await this.checkROAS(tenantId, config.roasMin);
    actions.push(...roasEvals);

    // 2. Max loss per day
    const lossEval = await this.checkDailyLoss(tenantId, config.maxLossPerDay);
    if (lossEval) actions.push(lossEval);

    // 3. Pixel freeze (spend sans revenue pendant X minutes)
    const pixelEval = await this.checkPixelFreeze(tenantId, config.pixelFreezeSuspendMinutes);
    if (pixelEval) actions.push(pixelEval);

    // 4. Error rate → metabolic throttle
    const errorEval = await this.checkErrorRate(tenantId, config.errorRateThresholdPct);
    if (errorEval) actions.push(errorEval);

    // Exécuter les actions déclenchées
    for (const action of actions) {
      await this.executeAction(action);
    }

    return actions;
  }

  // ─── ROAS check ─────────────────────────────────────────────
  private async checkROAS(tenantId: string, roasMin: number): Promise<StopLossEvaluation[]> {
    const result = await db.query(
      `SELECT 
         c.id as campaign_id,
         c.platform,
         COALESCE(m.spend, 0) as spend,
         COALESCE(m.revenue, 0) as revenue,
         CASE WHEN COALESCE(m.spend, 0) > 0 
           THEN COALESCE(m.revenue, 0) / m.spend 
           ELSE 0 
         END as roas
       FROM campaigns c
       LEFT JOIN campaign_metrics_hourly m ON m.campaign_id = c.id
         AND m.hour >= NOW() - INTERVAL '24 hours'
       WHERE c.tenant_id = $1 
         AND c.status = 'ACTIVE'
         AND COALESCE(m.spend, 0) > 10 -- Minimum spend pour évaluer
       GROUP BY c.id, c.platform, m.spend, m.revenue
       HAVING CASE WHEN COALESCE(m.spend, 0) > 0 
                THEN COALESCE(m.revenue, 0) / m.spend 
                ELSE 0 END < $2`,
      [tenantId, roasMin]
    );

    return result.rows.map(row => ({
      action: 'pause_campaign' as const,
      reason: `ROAS ${row.roas.toFixed(2)} below minimum ${roasMin}`,
      campaignId: row.campaign_id,
      tenantId,
      metricValue: parseFloat(row.roas),
      threshold: roasMin,
    }));
  }

  // ─── Daily loss check ────────────────────────────────────────
  private async checkDailyLoss(tenantId: string, maxLoss: number): Promise<StopLossEvaluation | null> {
    const result = await db.query(
      `SELECT COALESCE(SUM(spend), 0) as total_spend, COALESCE(SUM(revenue), 0) as total_revenue
       FROM campaign_metrics_hourly m
       JOIN campaigns c ON c.id = m.campaign_id
       WHERE c.tenant_id = $1 AND m.hour >= NOW() - INTERVAL '24 hours'`,
      [tenantId]
    );

    const { total_spend, total_revenue } = result.rows[0];
    const loss = parseFloat(total_spend) - parseFloat(total_revenue);

    if (loss >= maxLoss) {
      return {
        action: 'freeze_tenant',
        reason: `Daily loss €${loss.toFixed(2)} exceeds max €${maxLoss}`,
        tenantId,
        metricValue: loss,
        threshold: maxLoss,
      };
    }
    return null;
  }

  // ─── Pixel freeze detector ───────────────────────────────────
  private async checkPixelFreeze(tenantId: string, freezeMinutes: number): Promise<StopLossEvaluation | null> {
    const result = await db.query(
      `SELECT 
         SUM(spend) as spend,
         SUM(conversions) as conversions
       FROM campaign_metrics_hourly m
       JOIN campaigns c ON c.id = m.campaign_id
       WHERE c.tenant_id = $1 
         AND m.hour >= NOW() - ($2 || ' minutes')::INTERVAL`,
      [tenantId, freezeMinutes]
    );

    const { spend, conversions } = result.rows[0];
    if (parseFloat(spend) > 5 && parseInt(conversions) === 0) {
      return {
        action: 'pixel_freeze',
        reason: `Spend €${parseFloat(spend).toFixed(2)} with 0 conversions in ${freezeMinutes}min — pixel may be broken`,
        tenantId,
        metricValue: parseFloat(spend),
        threshold: 0,
      };
    }
    return null;
  }

  // ─── Error rate → metabolic throttle ────────────────────────
  private async checkErrorRate(tenantId: string, thresholdPct: number): Promise<StopLossEvaluation | null> {
    const result = await db.query(
      `SELECT 
         COUNT(*) FILTER (WHERE status = 'failed') as failures,
         COUNT(*) as total
       FROM actions_queue
       WHERE tenant_id = $1 AND created_at >= NOW() - INTERVAL '15 minutes'`,
      [tenantId]
    );

    const { failures, total } = result.rows[0];
    if (parseInt(total) < 10) return null; // Pas assez d'échantillon

    const errorRate = (parseInt(failures) / parseInt(total)) * 100;
    if (errorRate >= thresholdPct) {
      return {
        action: 'metabolic_throttle',
        reason: `Error rate ${errorRate.toFixed(1)}% exceeds ${thresholdPct}% — throttling to 50%`,
        tenantId,
        metricValue: errorRate,
        threshold: thresholdPct,
      };
    }
    return null;
  }

  // ─── Execute action + log ────────────────────────────────────
  private async executeAction(evaluation: StopLossEvaluation): Promise<void> {
    if (evaluation.action === 'none') return;

    logger.warn({ evaluation }, `RISK_ENGINE: ${evaluation.action} triggered`);

    switch (evaluation.action) {
      case 'pause_campaign':
        if (evaluation.campaignId) {
          await db.query(
            `UPDATE campaigns SET status = 'PAUSED', paused_by = 'RISK_ENGINE', updated_at = NOW()
             WHERE id = $1`,
            [evaluation.campaignId]
          );
        }
        break;

      case 'freeze_tenant':
        await db.query(
          `UPDATE tenants SET kill_switch_active = true, kill_switch_reason = $2, updated_at = NOW()
           WHERE id = $1`,
          [evaluation.tenantId, evaluation.reason]
        );
        // Pause toutes les campaigns actives du tenant
        await db.query(
          `UPDATE campaigns SET status = 'PAUSED', paused_by = 'RISK_ENGINE', updated_at = NOW()
           WHERE tenant_id = $1 AND status = 'ACTIVE'`,
          [evaluation.tenantId]
        );
        break;

      case 'metabolic_throttle':
        await db.query(
          `UPDATE tenants SET worker_throttle_pct = 50, updated_at = NOW() WHERE id = $1`,
          [evaluation.tenantId]
        );
        break;

      case 'pixel_freeze':
        // Pause campaigns + alert (pas de freeze complet, peut être un bug ponctuel)
        await db.query(
          `UPDATE campaigns SET status = 'PAUSED', paused_by = 'RISK_ENGINE', updated_at = NOW()
           WHERE tenant_id = $1 AND status = 'ACTIVE'`,
          [evaluation.tenantId]
        );
        break;
    }

    // Log immutable
    await db.query(
      `INSERT INTO risk_events 
       (tenant_id, event_type, campaign_id, triggered_by, rule_violated, metric_value, threshold_value, action_taken)
       VALUES ($1, $2, $3, 'RISK_ENGINE', $4, $5, $6, $7)`,
      [
        evaluation.tenantId,
        evaluation.action,
        evaluation.campaignId ?? null,
        evaluation.reason,
        evaluation.metricValue,
        evaluation.threshold,
        evaluation.action,
      ]
    );
  }

  // ─── Kill switch global ──────────────────────────────────────
  async triggerKillSwitch(tenantId: string, triggeredBy: string): Promise<void> {
    await db.query(
      `UPDATE tenants 
       SET kill_switch_active = true, kill_switch_reason = 'Manual kill switch by ' || $2, updated_at = NOW()
       WHERE id = $1`,
      [tenantId, triggeredBy]
    );
    await db.query(
      `UPDATE campaigns SET status = 'PAUSED', paused_by = 'KILL_SWITCH', updated_at = NOW()
       WHERE tenant_id = $1 AND status = 'ACTIVE'`,
      [tenantId]
    );
    await db.query(
      `UPDATE actions_queue SET status = 'cancelled'
       WHERE tenant_id = $1 AND status IN ('pending', 'claimed')`,
      [tenantId]
    );
    logger.error({ tenantId, triggeredBy }, 'KILL SWITCH ACTIVATED');
  }

  // ─── Get risk config (stage-based) ──────────────────────────
  private async getConfig(tenantId: string): Promise<RiskConfig> {
    const result = await db.query(
      `SELECT risk_config FROM tenants WHERE id = $1`,
      [tenantId]
    );
    const config = result.rows[0]?.risk_config ?? {};
    
    return {
      roasMin: config.roas_min ?? 2.0,
      maxLossPerDay: config.max_loss_day ?? 500,
      budgetCapPerAdset: config.budget_cap_adset ?? 50,
      cooldownMinutes: config.cooldown_minutes ?? 60,
      errorRateThresholdPct: config.error_rate_threshold_pct ?? 15,
      pixelFreezeSuspendMinutes: config.pixel_freeze_minutes ?? 120,
    };
  }
}

export const riskEngineAgent = new RiskEngineAgent();
